(()=>{
const $=id=>document.getElementById(id);
const defaults={coins:0,power:1,level:1,auto:0,record:0,powerLevel:0};
let s={...defaults};
try{const saved=JSON.parse(localStorage.getItem('pixel-clicker-save'));if(saved&&Number.isFinite(saved.coins)&&saved.coins>=0)s={...defaults,...saved};}catch(e){}
const powerCost=()=>10*(s.powerLevel+1);
const autoCost=()=>50*Math.pow(2,s.auto);
function save(show=true){try{localStorage.setItem('pixel-clicker-save',JSON.stringify(s));if(show)$('status').textContent='Игра сохранена!';}catch(e){$('status').textContent='Не удалось сохранить прогресс в этом браузере.';}}
function render(){
 s.record=Math.max(s.record,Math.floor(s.coins));
 $('coins').textContent=Math.floor(s.coins).toLocaleString('ru-RU');
 $('level').textContent=s.level;$('power').textContent=s.power;$('auto').textContent=s.auto;
 $('record').textContent=s.record.toLocaleString('ru-RU');
 $('upgrades').textContent=s.powerLevel+s.auto;
 $('powerCost').textContent=powerCost()+' 🪙';$('autoCost').textContent=autoCost()+' 🪙';
 $('buyPower').disabled=s.coins<powerCost();$('buyAuto').disabled=s.coins<autoCost();
 const target=s.level*50;$('progress').style.width=Math.min(100,s.coins/target*100)+'%';
 $('goal').textContent='До следующего уровня: '+Math.max(0,Math.ceil(target-s.coins))+' монет';
}
function add(n){s.coins+=n;while(s.coins>=s.level*50){s.level++;$('message').textContent='★ НОВЫЙ УРОВЕНЬ! ★';}render();save(false);}
$('tap').addEventListener('click',()=>{add(s.power);$('message').textContent='+'+s.power+' монет!';});
$('buyPower').addEventListener('click',()=>{const c=powerCost();if(s.coins<c)return;s.coins-=c;s.power++;s.powerLevel++;$('message').textContent='Суперклик улучшен!';render();save(false);});
$('buyAuto').addEventListener('click',()=>{const c=autoCost();if(s.coins<c)return;s.coins-=c;s.auto++;$('message').textContent='Автокликер куплен!';render();save(false);});
$('save').addEventListener('click',()=>save(true));
$('reset').addEventListener('click',()=>{if(!confirm('Сбросить весь прогресс и рекорд?'))return;s={...defaults};save(false);render();$('message').textContent='Новая игра началась!';$('status').textContent='Прогресс сброшен.';});
setInterval(()=>{if(s.auto)add(s.auto);},1000);
document.addEventListener('visibilitychange',()=>{if(document.hidden)save(false);});
if('serviceWorker' in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));
render();
})();